package br.impacta.edu.ex3;


import java.util.List;
import java.util.Scanner;

public final class AgendaApp {
	private static Scanner entrada = new Scanner(System.in);
	private static IContatoDAO iContatoDAO = new ContatoDaoArquivo("contatos.txt");
	private static AgendaLeitura agendaLeitura = new AgendaLeitura();
	
	public static void main(String[] args) {
		
		boolean sair = false;
		while (!sair ) {
			Integer opcao = apresentarMenuPrincipal();
			switch (opcao) {
			case 1:
				inserirContato();
				break;
			case 2:
				buscarContato();
				break;
			case 3:	
				System.out.println("Saindo da agenda !"); 
				sair = true;
				break;
	
			default:
				System.out.println("Op��o invalida !");
				break;
			}
		}
	}

	private static void buscarContato() {
		System.out.println("\n Busca de Contatos : ");
		List<Contato> contatos = iContatoDAO.buscar(agendaLeitura.lerNome());
		
		if(contatos.size() == 0){
			System.out.println("N�o h� contato com este nome !");
		}else{
			for (Contato contato : contatos) {
				System.out.println(contato);
			}
		}
		
	}

	private static void inserirContato() {
		System.out.println("\n INSER��O de NOVO CONTATO");
		Contato contato = new Contato(agendaLeitura.lerNome(),agendaLeitura.lerTelefone());
		if(iContatoDAO.existe(contato)){
			System.out.println("Este contato j� est� cadastrado!");
		}else{
			iContatoDAO.inserir(contato);
		}

		
		
	}

	private static Integer apresentarMenuPrincipal() {
		Boolean inteiro = Boolean.FALSE;
		Integer opcao = new Integer("0");
		while(!inteiro){
				System.out.println("\nAgenda Telefonica");
				System.out.println("(1)Inserir");
				System.out.println("(2)Buscar");
				System.out.println("(3)Sair");
				System.out.print("Escolha uma opcao : ");
				
			try {
				opcao = Integer.parseInt(entrada.nextLine());
				inteiro = Boolean.TRUE;
			} catch (Exception e) {
				System.out.println("Erro : opcao deve ser um valor inteiro !");
			}
		}
		
		return opcao;
	}
	
}
