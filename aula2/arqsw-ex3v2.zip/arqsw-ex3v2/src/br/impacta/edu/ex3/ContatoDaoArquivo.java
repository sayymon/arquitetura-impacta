package br.impacta.edu.ex3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class ContatoDaoArquivo implements IContatoDAO{
	
	private String nomeArquivo;
	public ContatoDaoArquivo(String nomeArquivo) {
		this.nomeArquivo = nomeArquivo;
	}
	
	@Override
	public List<Contato> buscar(final String nome) {
		List<Contato> resultado = new ArrayList<Contato>();
		for (Contato contato : lerTodos()) {
			if (nome.equals(contato.getNome())) {
				resultado.add(contato);
			}
		}
		
		return resultado; 
		
	}
	
	private List<Contato> lerTodos() {
		List<Contato> result = new ArrayList<>();
		try {
			FileReader fr = new FileReader(nomeArquivo);
			BufferedReader br = new BufferedReader(fr);
			String linha;
			while ((linha = br.readLine()) != null) {
				String[] split = linha.split(";");
				Contato c = new Contato(split[0], split[1]);
				result.add(c);
			}
		} catch (IOException ee) {
			ee.printStackTrace();
		}
		return result;
	}

	@Override
	public void inserir(final Contato contato) {
		FileWriter arq;
		try {
			PrintWriter gravarArq = new PrintWriter(nomeArquivo);
			gravarArq.println(contato.getContatoFormatoArquivo());
			gravarArq.close();
		} catch (IOException e) {
			System.err.println("Erro ao salvar no arquivo");
		}

	}

	@Override
	public boolean existe(final Contato contato) {
		return lerTodos().contains(contato);
	}

	
}
