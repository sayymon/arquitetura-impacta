/**
 * 
 */
package br.impacta.edu.ex3;

import java.util.List;

/**
 * @author 1600273
 *
 */
public interface IContatoDAO {
	public List<Contato> buscar(final String nome);
	public void inserir(final Contato contato);
	public boolean existe(final Contato contato);
}
