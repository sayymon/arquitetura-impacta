package br.impacta.edu.ex3;

import java.util.Scanner;

public class AgendaLeitura {

	private static Scanner entrada = new Scanner(System.in);
	
	String lerTelefone() {
		System.out.println("Informe o telefone : ");
		String telefone = null;
		boolean valido = false;
		while (!valido) {
			telefone = entrada.nextLine();
			if(telefone.length() == 0 || telefone.length() > 25){
				valido = false;
				System.out.println("ERRO : telefone de tamanho invalido");
			}else{
				valido = true;
			}
		}
		
		return telefone;
	}

	String lerNome() {
		System.out.println("Informe o nome : ");
		String nome = null;
		boolean valido = false;
		while (!valido) {
			nome = entrada.nextLine();
			if(nome.length() == 0 || nome.length() > 200){
				valido = false;
				System.out.println("ERRO : nome de tamanho invalido");
			}else{
				valido = true;
			}
		}
		
		return nome;
	}	
	
}
