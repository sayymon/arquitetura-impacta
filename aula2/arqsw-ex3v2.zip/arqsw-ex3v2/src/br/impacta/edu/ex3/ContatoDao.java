package br.impacta.edu.ex3;

import java.util.ArrayList;
import java.util.List;

public class ContatoDao implements IContatoDAO{
	
	private static List<Contato> contatos = new ArrayList<Contato>();
	
	@Override
	public List<Contato> buscar(final String nome) {
		List<Contato> resultado = new ArrayList<Contato>();
		for (Contato contato : contatos) {
			if (nome.equals(contato.getNome())) {
				resultado.add(contato);
			}
		}
		
		return resultado; 
		
		
	}
	
	@Override
	public void inserir(final Contato contato) {
		contatos.add(contato);
	}

	@Override
	public boolean existe(final Contato contato) {
		return contatos.contains(contato);
	}

	
}
