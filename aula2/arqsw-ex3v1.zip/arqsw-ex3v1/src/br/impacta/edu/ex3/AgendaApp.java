package br.impacta.edu.ex3;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public final class AgendaApp {
	private static Scanner entrada = new Scanner(System.in);
	private static List<Contato> contatos = new ArrayList<Contato>();
	private static List<Contato> resultado = new ArrayList<Contato>();

	public static void main(String[] args) {
		
		boolean sair = false;
		while (!sair ) {
			Integer opcao = apresentarMenuPrincipal();
			switch (opcao) {
			case 1:
				inserirContato();
				break;
			case 2:
				buscarContato();
				break;
			case 3:	
				System.out.println("Saindo da agenda !"); 
				sair = true;
				break;
	
			default:
				System.out.println("Op��o invalida !");
				break;
			}
		}
	}

	private static void buscarContato() {
		String nome = lerNome();
		for (Contato contato : contatos) {
			if (nome.equals(contato.getNome())) {
				resultado.add(contato);
			}
		}
		
		if(resultado.size() == 0){
			System.out.println("N�o h� contato com este nome !");
		}else{
			for (Contato contato : contatos) {
				System.out.println(contato);
			}
		}
		
		
	}

	private static void inserirContato() {
		System.out.println("\n INSER��O de NOVO CONTATO");
		String nome = lerNome();
		String telefone = lerTelefone();
		Contato contato = new Contato(nome,telefone);
		
		if(contatos.contains(contato)){
			System.out.println("Este contato j� est� cadastrado!");
		}else{
			contatos.add(contato);
		}
		
		
	}

	private static String lerTelefone() {
		System.out.println("Informe o telefone : ");
		String telefone = null;
		boolean valido = false;
		while (!valido) {
			telefone = entrada.nextLine();
			if(telefone.length() == 0 || telefone.length() > 25){
				valido = false;
				System.out.println("ERRO : telefone de tamanho invalido");
			}else{
				valido = true;
			}
		}
		
		return telefone;
	}

	private static String lerNome() {
		System.out.println("Informe o nome : ");
		String nome = null;
		boolean valido = false;
		while (!valido) {
			nome = entrada.nextLine();
			if(nome.length() == 0 || nome.length() > 200){
				valido = false;
				System.out.println("ERRO : nome de tamanho invalido");
			}else{
				valido = true;
			}
		}
		
		return nome;
	}

	private static Integer apresentarMenuPrincipal() {
		Boolean inteiro = Boolean.FALSE;
		Integer opcao = new Integer("0");
		while(!inteiro){
				System.out.println("\nAgenda Telefonica");
				System.out.println("(1)Inserir");
				System.out.println("(2)Buscar");
				System.out.println("(3)Sair");
				System.out.print("Escolha uma opcao : ");
				
			try {
				opcao = Integer.parseInt(entrada.nextLine());
				inteiro = Boolean.TRUE;
			} catch (Exception e) {
				System.out.println("Erro : opcao deve ser um valor inteiro !");
			}
		}
		
		return opcao;
	}
	
}
