package br.edu.impacta.arq4;


import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class SaudacaoClient {

	@SuppressWarnings("resource")
	
	public static void main(String[] args) throws UnknownHostException, IOException {
		String nome = showInputDialog("Qual � o seu nome");
		Socket soc = new Socket("172.18.33.45",58888);
		
		InputStream is = soc.getInputStream();
		
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		
		OutputStream os = soc.getOutputStream();
		PrintWriter pw = new PrintWriter(os);
		
		pw.println(nome);
		pw.flush();
		
		String resposta = br.readLine();
		showMessageDialog(null, "Resposta do Servidor:"+resposta);
		
		pw.close();
		br.close();
		soc.close();
		
		
		
		
	}
}
